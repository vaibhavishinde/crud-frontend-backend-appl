$(document).ready(function () {
    
    let data = [];

    
    function displayData() {
        let table = '<table class="table table-striped">';
        table += '<thead><tr><th>Name</th><th>Email</th><th>Action</th></tr></thead>';
        table += '<tbody>';
        data.forEach((item, index) => {
            table += `<tr><td>${item.name}</td><td>${item.email}</td><td><button class="btn btn-warning btn-edit" data-index="${index}">Edit</button> <button class="btn btn-danger btn-delete" data-index="${index}">Delete</button></td></tr>`;
        });
        table += '</tbody></table>';
        $("#data").html(table);

      
        $(".btn-edit").click(function () {
            let index = $(this).data("index");
            let editedName = prompt("Edit Name:", data[index].name);
            let editedEmail = prompt("Edit Email:", data[index].email);
            if (editedName !== null && editedEmail !== null) {
                data[index].name = editedName;
                data[index].email = editedEmail;
                displayData();
            }
        });

        
        $(".btn-delete").click(function () {
            let index = $(this).data("index");
            if (confirm("Are you sure you want to delete this record?")) {
                data.splice(index, 1);
                displayData();
            }
        });
    }

    
    $("#createForm").submit(function (event) {
        event.preventDefault();
        let name = $("#name").val();
        let email = $("#email").val();
        data.push({ name, email });
        $("#name").val("");
        $("#email").val("");
        displayData();
    });

    displayData();
});
